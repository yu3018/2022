from pu_flask import app, socketio
from flask_socketio import SocketIO, join_room, leave_room
from flask_login import current_user, login_required
from flask import session,render_template,redirect,url_for,flash

online_user = []

#似乎可以設定多個房間
@app.route("/chat_room")
@login_required
def chat_room():
    return render_template('home-u/chat_room.html', username=current_user.username, room='')
    

# 連接
@socketio.on('connect')
def handle_connect():
    username = current_user.username
    if username not in online_user:
        online_user.append(username)


# 段開連接
@socketio.on('disconnect')
def handle_disconnect():
    username = current_user.username
    print('connect info:  ' + f'{username}  disconnect')
    


@socketio.on('send msg')
def handle_message(data):
    print('sendMsg' + str(data))
    room = ''
    data['message'] = data.get('message').replace('<', '&lt;').replace('>', '&gt;').replace(' ', '&nbsp;')
    socketio.emit('send msg', data, to=room)


@socketio.on('join')
def on_join(data):
    username = data.get('username')
    room = data.get('room')
    join_room(room)
    print(online_user)
    print('join room:  ' + str(data))
    socketio.emit('connect info', username + '加入房間', to=room)


@socketio.on('leave')
def on_leave(data):
    username = data.get('username')
    room = data.get('room')
    leave_room(room)
    online_user.remove(current_user.username)
    print('leave room   ' + str(data))
    socketio.emit('connect info', username + '離開房間', to=room)




if __name__ == "__main__": #如果主程式執行  from .__init__  -->毒坑   還不知道啥時要加什麼時候要加 ， 什麼時候不加
    socketio.run(app,debug = True)