class Config:       #基礎參數
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_DATABASE_URI = 'postgresql://hybhdxtumwhvgt:123d1464b35bdb4e97e28653df439e8ec725edf0ec9715e788519044dad33a4b@ec2-52-5-110-35.compute-1.amazonaws.com:5432/d60on60vo4seon'
    SECRET_KEY = 'banana'
    DEBUG = True
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PROT = 465
    MAIL_USE_TLS = True 
    MAIL_USERNAME = 'pulearnx@gmail.com'
    MAIL_PASSWORD = 'gzhzubdhzndskamg'
    SESSION_PROTECTION = None #'strong'  -->設strong有時登入資料會不見

    
    