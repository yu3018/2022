from flask import Flask
from datetime import timedelta
from flask_sqlalchemy import SQLAlchemy
from config import Config
from flask_bcrypt import Bcrypt
from flask_mail import Mail
from flask_login import LoginManager
import boto3
from flask_socketio import SocketIO

app = Flask(__name__) 
app.config.from_object(Config)
app.permanent_session_lifetime = timedelta(days=7) #關掉瀏覽器再開啟瀏覽器,使用者登入資料仍然還在並持續7天
socketio = SocketIO(app)
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)    #密碼加密
mail = Mail(app)       

photo_urll = 'https://pupuheroku.s3.ap-northeast-1.amazonaws.com/default_member.jpg'
s3 = boto3.client('s3', aws_access_key_id='AKIAVWZGD6AYXIBOEFG5', aws_secret_access_key='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')
BUCKET = 'pupuheroku'
bucket_resource = s3

login = LoginManager()      
login.init_app(app)
login.login_view = 'home.index'  
login.login_message = '請先登入帳號'

from .home.models import User

@login.user_loader      
def load_user(user_id):     #回傳使用者資訊
    return db.session.query(User).get(int(user_id))#User.query.get(int(user_id))->這個會time out崩壞!!


from .home.__init__ import home_bp  
app.register_blueprint(home_bp, url_prefix='/home')  #註冊藍圖
from .home_u.__init__ import home_u_bp
app.register_blueprint(home_u_bp, url_prefix='/home_u')


