function showalert() {
  //alert("輸入ctrl + D\n加入書籤。");
  swal("加入書籤","輸入ctrl + D","info")
}

function toggleMenu(number){
  var menu=document.getElementById("menu-"+number);
  menu.classList.toggle("hide");
  
}

function push(){
  //alert("請先進行登入 , 才能進行發帖！")
  swal("請先進行登入","","warning");
}
