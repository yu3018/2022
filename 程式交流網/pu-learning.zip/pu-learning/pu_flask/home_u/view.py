from pu_flask.home_u.__init__ import home_u_bp
from flask_login import login_required, current_user, logout_user
from flask import render_template, redirect, url_for, request, flash
from ..home_u.form import FormPost, FormSetting
from .models import post
from ..home.models import User
from datetime import datetime
from slugify import slugify
from ..home.models import db
from .. import bucket_resource, BUCKET, photo_urll
from werkzeug.utils import secure_filename
import uuid, os

def title_number(s):            #文章title字數處理
    if s ==  None:
        return s
    elif len(s.title) > 6:
        s.title = s.title[0:6] + "..."
    return s

@login_required
def gather2(s2,category,U,page):
    if s2 == 'home-u/index.html':
        world = post.query.filter(post.category == '社會工作兒童少年福利學系').count()
        worldn = title_number(post.query.filter(post.category == '社會工作兒童少年福利學系').order_by(post.create_date).first())
        english = post.query.filter(post.category == '英國語文學系').count()
        englishn = title_number(post.query.filter(post.category == '英國語文學系').order_by(post.create_date).first())
        spain = post.query.filter(post.category == '西班牙語文學').count()
        spainn = title_number(post.query.filter(post.category == '西班牙語文學').order_by(post.create_date).first())
        japan = post.query.filter(post.category == '日本語文學系').count()
        japann = title_number(post.query.filter(post.category == '日本語文學系').order_by(post.create_date).first())
        java = post.query.filter(post.category == 'Java程式').count()
        javan = title_number(post.query.filter(post.category == 'Java程式').order_by(post.create_date).first())
        python = post.query.filter(post.category == 'Python程式').count()
        pythonn = title_number(post.query.filter(post.category == 'Python程式').order_by(post.create_date).first())
        cpp = post.query.filter(post.category == 'C++程式').count()
        cppn = title_number(post.query.filter(post.category == 'C++程式').order_by(post.create_date).first())
        linux = post.query.filter(post.category == 'Linux程式').count()
        linuxn = title_number(post.query.filter(post.category == 'Linux程式').order_by(post.create_date).first())
        chemical = post.query.filter(post.category == '應用化學系').count()
        chemicaln = title_number(post.query.filter(post.category == '應用化學系').order_by(post.create_date).first())
        cosmetic = post.query.filter(post.category == '化妝品科學系').count()
        cosmeticn = title_number(post.query.filter(post.category == '化妝品科學系').order_by(post.create_date).first())
        financial = post.query.filter(post.category == '財務工程學系').count()
        financialn = title_number(post.query.filter(post.category == '財務工程學系').order_by(post.create_date).first())
        food = post.query.filter(post.category == '食品營養學系').count()
        foodn = title_number(post.query.filter(post.category == '食品營養學系').order_by(post.create_date).first())
        science = post.query.filter(post.category == '資訊科學學系').count()
        sciencen = title_number(post.query.filter(post.category == '資訊科學學系').order_by(post.create_date).first())
        china = post.query.filter(post.category == '中國文學系').count()
        chinan = title_number(post.query.filter(post.category == '中國文學系').order_by(post.create_date).first())
        people = post.query.filter(post.category == '生態人文學系').count()
        peoplen = title_number(post.query.filter(post.category == '生態人文學系').order_by(post.create_date).first())
        law = post.query.filter(post.category == '法律學系').count()
        lawn = title_number(post.query.filter(post.category == '法律學系').order_by(post.create_date).first())
        public = post.query.filter(post.category == '大眾傳播學系').count()
        publicn = title_number(post.query.filter(post.category == '大眾傳播學系').order_by(post.create_date).first())
        taiwan = post.query.filter(post.category == '台灣文學系').count()
        taiwann = title_number(post.query.filter(post.category == '台灣文學系').order_by(post.create_date).first())
        Cp = post.query.filter(post.category == 'C').count()
        Cpn = title_number(post.query.filter(post.category == 'C').order_by(post.create_date).first())
        return render_template(s2, User=current_user, world=world, english=english, spain=spain, japan=japan, java=java, python=python, cpp=cpp, linux=linux
            , chemical=chemical, cosmetic=cosmetic, financial=financial, food=food, science=science, china=china, people=people, law=law, public=public, taiwan=taiwan, Cp=Cp, javan=javan,
            worldn=worldn, englishn=englishn, spainn=spainn, japann=japann, pythonn=pythonn, cppn=cppn, linuxn=linuxn, chemicaln=chemicaln, cosmeticn=cosmeticn
            , financialn=financialn, foodn=foodn, sciencen=sciencen, chinan=chinan, peoplen=peoplen, lawn=lawn, publicn=publicn, taiwann=taiwann, Cpn=Cpn)
    elif category == '':
        return render_template(s2,User=current_user)
    P = post.query.filter(post.category == category).order_by(post.create_date).paginate(page, 5, False)        
    return render_template(s2,User=current_user,P=P,U=U,category=category)
  

@home_u_bp.route("/index",methods=["POST","GET"])
def index2():
    return gather2('home-u/index.html','','','')


@home_u_bp.route("/chat")
@home_u_bp.route("/chat/<int:page>")
def chat2(page=1):
    return gather2('home-u/chat.html','哈拉板','home_u.chat2',page)

@home_u_bp.route("/activity")
@home_u_bp.route("/activity/<int:page>")  
def activity2(page=1):
    return gather2('home-u/activity.html','活動分享區','home_u.activity2',page)

@home_u_bp.route("/community")
@home_u_bp.route("/community/<int:page>")
def community2(page=1):
    return gather2('home-u/community.html','社群招生板','home_u.community2',page)

@home_u_bp.route("/report")                 #排行榜
def report2():
    U = User.query.filter(User.confirm != False).order_by(-User.point).all()
    return render_template('home-u/report.html',User=current_user, U=U)


@home_u_bp.route("/creat")
@home_u_bp.route("/creat/<int:page>")
def creat2(page=1):
    return gather2('home-u/creat.html','藝術創作分享區','home_u.creat2',page)

@home_u_bp.route("/put")
def put2():
    return gather2('home-u/put.html','','')

@home_u_bp.route("/java")
@home_u_bp.route("/java/<int:page>")
def java2(page=1):
    return gather2('home-u/program/java.html','Java程式','home_u.java2',page)

@home_u_bp.route("/python")
@home_u_bp.route("/python/<int:page>")
def python2(page=1):
    return gather2('home-u/program/python.html','Python程式','home_u.python2',page)

@home_u_bp.route("/Cp")
@home_u_bp.route("/Cp/<int:page>")
def Cp2(page=1):
    return gather2('home-u/program/Cp.html','C','home_u.Cp2',page)

@home_u_bp.route("/cpp")
@home_u_bp.route("/cpp/<int:page>")
def cpp2(page=1):
    return gather2('home-u/program/cpp.html','C++程式','home_u.cpp2',page)

@home_u_bp.route("/linux")
@home_u_bp.route("/linux/<int:page>")
def linux2(page=1):
    return gather2('home-u/program/linux.html','Linux程式','home_u.linux2',page)

@home_u_bp.route("/c")   #沒有?
@home_u_bp.route("/c/<int:page>")   
def c2(page=1):
    return gather2('home-u/program/c.html','home_u.c2',page)

@home_u_bp.route("/chemical")
@home_u_bp.route("/chemical/<int:page>")
def chemical2(page=1):
    return gather2('home-u/money/chemical.html','應用化學系','home_u.chemical2',page)
    
@home_u_bp.route("/cosmetic")
@home_u_bp.route("/cosmetic/<int:page>")
def cosmetic2(page=1):
    return gather2('home-u/money/cosmetic.html','化妝品科學系','home_u.cosmetic2',page)

@home_u_bp.route("/financial")
@home_u_bp.route("/financial/<int:page>")
def financial2(page=1):
    return gather2('home-u/money/financial.html','財務工程學系','home_u.financial2',page)

@home_u_bp.route("/food")
@home_u_bp.route("/food/<int:page>")
def food2(page=1):
    return gather2('home-u/money/food.html','食品營養學系','home_u.food2',page)

@home_u_bp.route("/science")
@home_u_bp.route("/science/<int:page>")
def science2(page=1):
    return gather2('home-u/money/science.html','資訊科學學系','home_u.science2',page)

@home_u_bp.route("/china")
@home_u_bp.route("/china/<int:page>")
def china2(page=1):
    return gather2('home-u/people/china.html','中國文學系','home_u.china2',page)

@home_u_bp.route("/human")
@home_u_bp.route("/human/<int:page>")
def human2(page=1):
    return gather2('home-u/people/human.html','生態人文學系','home_u.human2',page)

@home_u_bp.route("/law")
@home_u_bp.route("/law/<int:page>")
def law2(page=1):
    return gather2('home-u/people/law.html','法律學系','home_u.law2',page)

@home_u_bp.route("/public")
@home_u_bp.route("/public/<int:page>")
def public2(page=1):
    return gather2('home-u/people/public.html','大眾傳播學系','home_u.public2',page)

@home_u_bp.route("/taiwan")
@home_u_bp.route("/taiwan/<int:page>")
def taiwan2(page=1):
    return gather2('home-u/people/taiwan.html','台灣文學系','home_u.taiwan2',page)

@home_u_bp.route("/world")
@home_u_bp.route("/world/<int:page>")
def world2(page=1):
    return gather2('home-u/people/world.html','社會工作兒童少年福利學系','home_u.world2',page)

@home_u_bp.route("/english")
@home_u_bp.route("/english/<int:page>")
def english2(page=1):
    return gather2('home-u/language/english.html','英國語文學系','home_u.english2',page)

@home_u_bp.route("/japan")
@home_u_bp.route("/japan/<int:page>")
def japan2(page=1):
    return gather2('home-u/language/japan.html','日本語文學系','home_u.japan2',page)

@home_u_bp.route("/spain")
@home_u_bp.route("/spain/<int:page>")
def spain2(page=1):
    return gather2('home-u/language/spain.html','西班牙語文學','home_u.spain2',page)


@home_u_bp.route("/setting",methods=["POST","GET"])        #設定
@login_required
def setting2():
    Settingform = FormSetting()
    if Settingform.validate_on_submit():
        if Settingform.image_uploads.data:
            img = Settingform.image_uploads.data

            ext = img.filename.rsplit(".",1)[1].lower()     #名字獨特性
            img.filename = f"{uuid.uuid4().hex}.{ext}"

            if current_user.photo != photo_urll:
                photo_url = current_user.photo.split('/')     #刪掉之前大頭貼
                bucket_resource.delete_object(Bucket=BUCKET, Key=photo_url[len(photo_url)-1])

            name = secure_filename(Settingform.image_uploads.data.filename)
            img.save(name)                  #先存檔

            bucket_resource.upload_file(            #資料傳到aws s3
                Bucket = BUCKET,
                Filename = name,
                Key = name
            )
            ur = f'http://{BUCKET}.s3.amazonaws.com/'
            url = f"{ur}{name}"

            os.remove(name)             #後刪除

            current_user.photo = url

        current_user.username = Settingform.username.data
        current_user.birthday = Settingform.birthday.data
        current_user.blood = Settingform.blood.data
        current_user.star = Settingform.star.data
        current_user.gender = Settingform.gender.data
        current_user.interest = Settingform.interest.data
        if len(Settingform.password.data) > 0:
            current_user.password = Settingform.password.data
        db.session.add(current_user)
        db.session.commit()
        flash("已更新個人檔案")
        return render_template('home-u/setting.html', User=current_user, regist_date=current_user.regist_date.strftime("%Y-%m-%d"), last_login=current_user.last_login.strftime("%Y-%m-%d"), Settingform = Settingform)
    Settingform.username.data = current_user.username
    if current_user.birthday != None:
        Settingform.birthday.data = current_user.birthday
    if current_user.blood != None:
        Settingform.blood.data = current_user.blood
    if current_user.star != None:
        Settingform.star.data = current_user.star
    if current_user.gender != None:
        Settingform.gender.data = current_user.gender      
    if current_user.interest != None:
        Settingform.interest.data = current_user.interest

    
    return render_template('home-u/setting.html', User=current_user, regist_date=current_user.regist_date.strftime("%Y-%m-%d"), last_login=current_user.last_login.strftime("%Y-%m-%d"), Settingform = Settingform)

@home_u_bp.route("/release/<category>",methods=["POST","GET"])         #發布文章頁面
@login_required
def release(category):
    Postform = FormPost()
    if Postform.validate_on_submit():
    
        p = post(title=Postform.title.data,
            body=Postform.body.data,
            category=category,
            author=current_user._get_current_object(),   #不使用current_user.id，要先取物件
            slug='%i-%i-%i-%i-%s' % (current_user.id, datetime.now().year, datetime.now().month, datetime.now().day, slugify(Postform.title.data) )  #slugify ->產生固定網址
        )
        db.session.add(p)
        db.session.commit()
        flash("已成功發布文章")
        return redirect(url_for("home_u.index2")) 
    return render_template('home-u/release.html',Postform=Postform, User=current_user, category=category)
    

@home_u_bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("home.index"))


@home_u_bp.route("/daily_quiz",methods=["POST","GET"])             
@login_required
def daily_quiz():                      #每日問答
    d = request.form.get('name')
    
    if d:
        current_user.point = current_user.point + 1
        current_user.daily_quiz = True
        db.session.add(current_user)
        db.session.commit()

    return redirect(url_for("home.index"))   #ajax似乎無效

