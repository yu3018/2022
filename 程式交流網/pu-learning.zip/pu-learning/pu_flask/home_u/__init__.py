from flask import Blueprint

#  定義
home_u_bp = Blueprint('home_u', __name__)
#  關聯
from . import view
# test