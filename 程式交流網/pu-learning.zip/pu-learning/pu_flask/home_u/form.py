from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, validators, PasswordField, EmailField, ValidationError, BooleanField, TextAreaField, SelectField, DateField
from flask_login import current_user
from flask_wtf.file import FileRequired, FileAllowed, FileField
from ..home.models import User
from datetime import datetime,timedelta

class FormPost(FlaskForm):              #文章表格
    title = StringField('', validators=[
        validators.DataRequired(),
        validators.Length(1, 20)
    ])
    body = TextAreaField('', validators=[
        validators.DataRequired()
    ])

    # category = SelectField(
    #     label = '',
    #     render_kw={
    #         'class':'form-control'
    #     },
    #     choices=[('活動', '活動'), ('社群', '社群'), ('社群', '社群'), ('哈拉版', '哈拉版')],
    #     default = 4,
    #     coerce=str
    # )

    image_uploads = FileField('', validators=[
    ])

    submit = SubmitField('送出')

class FormSetting(FlaskForm):         #個人設定表格
    username = StringField('', validators=[
        validators.DataRequired(),
        validators.Length(1, 10)
    ])
    birthday = DateField('', format="%Y-%m-%d", default = datetime(2022,2,2)
    )
    image_uploads = FileField('', validators=[
        FileAllowed(['jpg','png'], 'IMAGE ONLY PLEASE!')
    ])
    star = SelectField(
        label = '',
        render_kw={
            'class':'form-control'
        },
        choices=[('牡羊座', '牡羊座'), ('金牛座', '金牛座'), ('雙子座', '雙子座'), ('巨蟹座', '巨蟹座'), ('獅子座', '獅子座'), ('處女座', '處女座'), ('天秤座', '天秤座'), ('天蠍座', '天蠍座'), ('射手座', '射手座'), ('魔羯座', '魔羯座'), ('水瓶座', '水瓶座'), ('雙魚座', '雙魚座')],
        coerce=str
    )
    gender = SelectField(
        label = '',
        render_kw={
            'class':'form-control'
        },
        choices=[('男生', '男生'), ('女生', '女生'), ('不公開', '不公開')],
        coerce=str
    )
    blood = SelectField(
        label = '',
        render_kw={
            'class':'form-control'
        },
        choices=[('O', 'O'), ('A', 'A'), ('B', 'B'), ('AB', 'AB'), ('不公開', '不公開')],
        coerce=str
    )
    password = PasswordField('', validators=[
        validators.EqualTo('password2', message='密碼不一致')
    ])
    password2 = PasswordField('', validators=[
    ])
    password_confirm = PasswordField('', validators=[
        validators.DataRequired(),
        validators.Length(8, 20)
    ])
    interest = StringField('')
    submit = SubmitField('送出')

    def validate_username(self, field):
        user = User.query.filter_by(username=field.data).first()
        if user and (current_user.username != field.data):
            raise ValidationError('名字已使用過')
    
    def validate_password(self, field):
        if len(field.data) < 8 and len(field.data) != 0:
            raise ValidationError('密碼長度要大於8')
    
    def validate_password_confirm(self, field):
        if not current_user.check_password(field.data):
            raise ValidationError('密碼錯誤')

        
    