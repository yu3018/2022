from .. import db,bcrypt
import jwt
from flask import current_app
from flask_login import UserMixin
from datetime import datetime,timedelta
class post(db.Model):                   #文章發布的資料庫
    __tablename__ = 'post'#fj
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(20))
    body = db.Column(db.Text)
    category = db.Column(db.String(20))
    author_id = db.Column(db.Integer, db.ForeignKey('useraccount.id'))         #fk-關聯
    create_date = db.Column(db.DateTime, default=datetime.utcnow)
    edit_date = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow) #更新就自動更新時間
    slug = db.Column(db.String(256), unique=True)


    def __init__(self, title, body, category, author, slug=None):
        self.title = title
        self.body = body
        self.category = category
        self.author_id = author.id
        self.slug = slug

    def __repr__(self):
        return '<POST> %s' % self.title
