from .. import db,bcrypt
import jwt
from flask import current_app
from flask_login import UserMixin
from datetime import datetime,timedelta

class User(UserMixin,db.Model):           #資料庫useraccount表,UserMixin為用戶狀態
    __tablename__ = 'useraccount'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50),unique=True,nullable=False)
    email = db.Column(db.String(50),unique=True,nullable=False)
    hash_password = db.Column(db.String(80),unique=True,nullable=False)  
    confirm = db.Column(db.Boolean, default=False)
    photo = db.Column(db.String(200))
    point = db.Column(db.Integer, nullable=False, default=0)
    gender = db.Column(db.String(10))
    regist_date = db.Column(db.DateTime, default=datetime.now)
    last_login = db.Column(db.DateTime, default=datetime.now)
    birthday = db.Column(db.DateTime)
    star = db.Column(db.String(10))
    interest = db.Column(db.String(100))
    daily_quiz = db.Column(db.Boolean, default=False,nullable=False)
    blood = db.Column(db.String(10))
    posts = db.relationship('post', backref='user', lazy='dynamic')  #關聯fk

    @property
    def password(self):                 #如果使用User.password會被阻止
        raise AttributeError('密碼不可讀取，不能做壞壞的事喔')

    @password.setter                #註冊的密碼進行加密並存在資料庫
    def password(self, password):
        self.hash_password = bcrypt.generate_password_hash(password).decode('utf8')

    def check_password(self, password):                #確認密碼是否正確
        return bcrypt.check_password_hash(self.hash_password, password)
    
    def create_regiest_token(self):   #生成token
        return jwt.encode({'id':self.id, "exp": datetime.utcnow() + timedelta(minutes=15)},current_app.config['SECRET_KEY'],algorithm = 'HS256')

    @staticmethod                   #靜態，沒有self(不是很清楚
    def check_regiest_token(token):   #確認token
        try:
            data = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
            return User.query.filter_by(id=data['id']).first()
        except:
            return
    
    def create_reset_token(self):   #生成token
        return jwt.encode({'id':self.id, "exp": datetime.utcnow() + timedelta(minutes=15)},current_app.config['SECRET_KEY'],algorithm = 'HS256')

    @staticmethod                   #靜態，沒有self(不是很清楚
    def check_reset_token(token):   #確認token
        try:
            data = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
            return User.query.filter_by(id=data['id']).first()
        except:
            return











