from flask_wtf import FlaskForm
from .models import User
from wtforms import StringField, SubmitField, validators, PasswordField, EmailField, ValidationError, BooleanField, TextAreaField, SelectField
from flask_login import current_user


class FormRegister(FlaskForm):       #註冊表格
    

    username = StringField('用戶名', validators=[
        validators.DataRequired(),
        validators.Length(1, 10)
    ])
    email = EmailField('電子信箱', validators=[
        validators.DataRequired(),
        validators.Length(1, 50),
        validators.Email()
    ])
    password = PasswordField('密碼', validators=[
        validators.DataRequired(),
        validators.Length(8, 20),
        validators.EqualTo('password2', message='密碼不一致')
    ])
    password2 = PasswordField('確認密碼', validators=[
        validators.DataRequired()
    ])
    submit = SubmitField('註冊')
    def validate_username(self, field):
        user = User.query.filter_by(username=field.data).first()
        if user:
            raise ValidationError('名字已使用過')
    def validate_email(self, field):
        if User.query.filter_by(email=field.data).first():
            raise ValidationError('信箱已註冊過')


class FormLogin(FlaskForm):                 #登入表格
    id1 = EmailField('信箱:', validators=[
        validators.DataRequired(),
        validators.Length(1, 50)
    ])
    password = PasswordField('密碼:', validators=[
        validators.DataRequired(),
        validators.Length(8, 20),
    ])

    remember_me = BooleanField('保持登入')

    submit = SubmitField('登入')
    
class FormForgetPa(FlaskForm): #忘記密碼取得驗證碼
    foemail = EmailField('電子信箱', validators=[
        validators.DataRequired(),
        validators.Length(1, 50),
    ])
    submit = SubmitField('取得信箱驗證碼')

    def validate_foemail(self, field):
        if validators.Email():
            if not User.query.filter_by(email=field.data).first():
                raise ValidationError('此信箱並未註冊')

class FormResetPa(FlaskForm):
    password = PasswordField('密碼', validators=[
        validators.DataRequired(),
        validators.Length(8, 20),
        validators.EqualTo('password2', message='密碼不一致')
    ])
    password2 = PasswordField('確認密碼', validators=[
        validators.DataRequired()
    ])
    submit = SubmitField('重設密碼')


    