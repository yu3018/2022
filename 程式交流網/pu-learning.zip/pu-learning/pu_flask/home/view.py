from flask import  redirect, render_template, request, url_for, flash, session
from .models import User,db  #db不能用__init__ import,不然會debug 1小時以上
import email.message
from .form import FormLogin, FormRegister, FormForgetPa, FormResetPa
from pu_flask.__init__ import app, photo_urll
from ..sendmail import send_mail
from flask_login import login_user, current_user, login_required, logout_user
from pu_flask.home.__init__ import home_bp
from datetime import datetime,timedelta
from ..home_u.models import post
from ..__init__ import socketio
from sqlalchemy import func

def index_data(n):
    form = FormRegister()
    Loform = FormLogin()
    Fopaform = FormForgetPa()
    world = post.query.filter(post.category == '社會工作兒童少年福利學系').count()
    worldn = title_number(post.query.filter(post.category == '社會工作兒童少年福利學系').order_by(post.create_date).first())
    english = post.query.filter(post.category == '英國語文學系').count()
    englishn = title_number(post.query.filter(post.category == '英國語文學系').order_by(post.create_date).first())
    spain = post.query.filter(post.category == '西班牙語文學').count()
    spainn = title_number(post.query.filter(post.category == '西班牙語文學').order_by(post.create_date).first())
    japan = post.query.filter(post.category == '日本語文學系').count()
    japann = title_number(post.query.filter(post.category == '日本語文學系').order_by(post.create_date).first())
    java = post.query.filter(post.category == 'Java程式').count()
    javan = title_number(post.query.filter(post.category == 'Java程式').order_by(post.create_date).first())
    python = post.query.filter(post.category == 'Python程式').count()
    pythonn = title_number(post.query.filter(post.category == 'Python程式').order_by(post.create_date).first())
    cpp = post.query.filter(post.category == 'C++程式').count()
    cppn = title_number(post.query.filter(post.category == 'C++程式').order_by(post.create_date).first())
    linux = post.query.filter(post.category == 'Linux程式').count()
    linuxn = title_number(post.query.filter(post.category == 'Linux程式').order_by(post.create_date).first())
    chemical = post.query.filter(post.category == '應用化學系').count()
    chemicaln = title_number(post.query.filter(post.category == '應用化學系').order_by(post.create_date).first())
    cosmetic = post.query.filter(post.category == '化妝品科學系').count()
    cosmeticn = title_number(post.query.filter(post.category == '化妝品科學系').order_by(post.create_date).first())
    financial = post.query.filter(post.category == '財務工程學系').count()
    financialn = title_number(post.query.filter(post.category == '財務工程學系').order_by(post.create_date).first())
    food = post.query.filter(post.category == '食品營養學系').count()
    foodn = title_number(post.query.filter(post.category == '食品營養學系').order_by(post.create_date).first())
    science = post.query.filter(post.category == '資訊科學學系').count()
    sciencen = title_number(post.query.filter(post.category == '資訊科學學系').order_by(post.create_date).first())
    china = post.query.filter(post.category == '中國文學系').count()
    chinan = title_number(post.query.filter(post.category == '中國文學系').order_by(post.create_date).first())
    people = post.query.filter(post.category == '生態人文學系').count()
    peoplen = title_number(post.query.filter(post.category == '生態人文學系').order_by(post.create_date).first())
    law = post.query.filter(post.category == '法律學系').count()
    lawn = title_number(post.query.filter(post.category == '法律學系').order_by(post.create_date).first())
    public = post.query.filter(post.category == '大眾傳播學系').count()
    publicn = title_number(post.query.filter(post.category == '大眾傳播學系').order_by(post.create_date).first())
    taiwan = post.query.filter(post.category == '台灣文學系').count()
    taiwann = title_number(post.query.filter(post.category == '台灣文學系').order_by(post.create_date).first())
    Cp = post.query.filter(post.category == 'C').count()
    Cpn = title_number(post.query.filter(post.category == 'C').order_by(post.create_date).first())    
    return render_template(session["notLogin"],data=n,form=form,Loform=Loform,Fopaform=Fopaform, world=world, english=english, spain=spain, japan=japan, java=java, python=python, cpp=cpp, linux=linux
    , chemical=chemical, cosmetic=cosmetic, financial=financial, food=food, science=science, china=china, people=people, law=law, public=public, taiwan=taiwan, Cp=Cp, javan=javan,
    worldn=worldn, englishn=englishn, spainn=spainn, japann=japann, pythonn=pythonn, cppn=cppn, linuxn=linuxn, chemicaln=chemicaln, cosmeticn=cosmeticn
    , financialn=financialn, foodn=foodn, sciencen=sciencen, chinan=chinan, peoplen=peoplen, lawn=lawn, publicn=publicn, taiwann=taiwann, Cpn=Cpn)



def title_number(s):            #文章title字數處理
    if s ==  None:
        return s
    elif len(s.title) > 6:
        s.title = s.title[0:6] + "..."
    
    return s

def gather1(s1,s2,category,U,page):       #登入或註冊
    session["notLogin"] = s1
    session["Login"] = s2
    form = FormRegister()
    Loform = FormLogin()
    Fopaform = FormForgetPa()
    if request.method == "POST":
        if request.form['submit']=='註冊':
            if form.validate_on_submit():
                user = User(username=form.username.data,email=form.email.data,password=form.password.data,regist_date=datetime.now(),photo=photo_urll)
                db.session.add(user)
                db.session.commit()
                token = user.create_regiest_token()
                db.session.close()
                send_mail(sender='pulearnx@gmail.com',
                  recipients=[user.email],
                  subject='驗證你的帳戶',
                  template='mail/welcome',
                  mailtype='html',
                  username=user.username,
                  token=token)
                flash('驗證郵件已寄出')
                if session["notLogin"] == 'home/report.html':
                    U = User.query.filter(User.confirm != False).order_by(-User.point).all()
                    return render_template(session["notLogin"],form=form,Loform=Loform,Fopaform=Fopaform, U=U)      #載入排行榜資料
                if category == '':             #進首頁
                    return index_data('0')
                return render_template(s1,form=form,Loform=Loform,Fopaform=Fopaform)
            else:
                if session["notLogin"] == 'home/report.html':
                    U = User.query.filter(User.confirm != False).order_by(-User.point).all()
                    return render_template(session["notLogin"],form=form,Loform=Loform,Fopaform=Fopaform, U=U, data='1')      #載入排行榜資料
                if category == '':             #進首頁
                    return index_data('1')
                return render_template(s1,form=form,Loform=Loform,Fopaform=Fopaform,data='1')
        elif request.form['submit']=='取得信箱驗證碼':
            
            if Fopaform.validate_on_submit():
                user = User.query.filter_by(email=Fopaform.foemail.data).first()
                token = user.create_reset_token()
                send_mail(sender='pulearnx@gmail.com',
                  recipients=[user.email],
                  subject='找回你的密碼',
                  template='mail/reset_pa',
                  mailtype='html',
                  username=user.username,
                  token=token)
                flash('驗證郵件已寄出')
            else:
                if session["notLogin"] == 'home/report.html':
                    U = User.query.filter(User.confirm != False).order_by(-User.point).all()
                    return render_template(session["notLogin"],form=form,Loform=Loform,Fopaform=Fopaform, U=U, data='2')      #載入排行榜資料
                if category == '':             #進首頁
                    return index_data('2')
                return render_template(s1,form=form,Loform=Loform,Fopaform=Fopaform,data='2')
        elif Loform.validate_on_submit():               #登入
            email = Loform.id1.data
            password = Loform.password.data
            user_object = User.query.filter_by(email=email).first()
            if user_object:
                if user_object.check_password(password) :
                    if datetime.now().strftime("%Y-%m-%d") != user_object.last_login.strftime("%Y-%m-%d"):   #判斷有沒有差一天
                        user_object.daily_quiz = False
                    user_object.last_login = datetime.now()                     #最後登入時間
                    db.session.add(user_object)
                    db.session.commit()
                    login_user(user_object, Loform.remember_me.data)
                    next = request.args.get('next')     #獲得參數next,next參數來自於使用者在未登錄狀態下跑到必須登錄才能訪問的網站url
                    if not next_is_valid(next):           #確認是否有權限
                        return 'Bad Boy!!'
                    return redirect(next or url_for(session["Login"]))
            flash('信箱或密碼錯誤')             #flash完要記得return
        if session["notLogin"] == 'home/report.html':
            U = User.query.filter(User.confirm != False).order_by(-User.point).all()
            return render_template(session["notLogin"],form=form,Loform=Loform,Fopaform=Fopaform, U=U)      #載入排行榜資料
        if category == '':             #進首頁
            return index_data('0')
        return render_template(session["notLogin"],form=form,Loform=Loform,Fopaform=Fopaform)
    else:
        if current_user.is_authenticated:               #用戶是否登入狀態
            return redirect(url_for(session["Login"]))
        elif session["notLogin"] == 'home/report.html':
            U = User.query.filter(User.confirm != False).order_by(-User.point).all()
            return render_template(session["notLogin"],form=form,Loform=Loform,Fopaform=Fopaform, U=U)      #載入排行榜資料
        if category == '':             #進首頁
            return index_data('0')
        P = post.query.filter(post.category == category).order_by(post.create_date).paginate(page, 5, False)
        return render_template(session["notLogin"],form=form,Loform=Loform,Fopaform=Fopaform,P=P,U=U)

def next_is_valid(next):        #自訂義url,可加上有權限的url
    return True
    
@home_bp.route('/post_content/<slug>',methods=["POST","GET"])       #文章內容
def post_content(slug):
    p = post.query.filter_by(slug = slug).first()
    form = FormRegister()
    Loform = FormLogin()
    Fopaform = FormForgetPa()
    if current_user.is_authenticated: 
        return render_template('home-u/put.html',Loform=Loform, Fopaform=Fopaform, form=form, p=p, User=current_user)
    return render_template('home/put.html',Loform=Loform, Fopaform=Fopaform, form=form, p=p)


@home_bp.before_app_request         #接受所有請求前先進在這函式
def before_request():       #確認使用者登入但未驗證通過
    if (current_user.is_authenticated and
            not current_user.confirm and
            request.endpoint != 'static' and
            request.endpoint not in ['home.re_userconfirm', 'home_u.logout']):
        return render_template('home/unactive.html')

@home_bp.route('/re_usreconfirm',methods=['POST','GET'])       #已註冊未驗證並重新發送郵件
@login_required
def re_userconfirm():
    token = current_user.create_regiest_token()
    send_mail(sender='pulearnx@gmail.com',
                  recipients=[current_user.email],
                  subject='驗證你的帳戶',
                  template='mail/welcome',
                  mailtype='html',
                  username=current_user.username,
                  token=token)
    logout_user()
    form = FormRegister()
    Loform = FormLogin()
    Fopaform = FormForgetPa()
    flash('郵件再次寄出,請刷新網頁')
    return render_template(session["notLogin"],form=form,Loform=Loform,Fopaform=Fopaform)
    
def forget_pa_sys():      #忘記密碼
    global email
    email = request.form['email']
    if User.query.filter_by(email=email).first():
        return ""
    return "信箱無效"

@home_bp.route('/register_confirm/<token>',methods=['POST','GET'])     #點擊信箱連結的位置
def register_confirm(token):
    user = User.check_regiest_token(token)
    if user:
        user.confirm = True
        db.session.commit()
        return render_template('mail/success_confirm.html')
    else:
        return render_template('mail/fail_confirm.html')


@home_bp.route('/reset_password/<token>',methods=['POST','GET'])     #點擊連結到重製密碼
def reset_password(token):
    if not current_user.is_anonymous:
        return redirect(url_for('home.index'))
    reform = FormResetPa()
    if reform.validate_on_submit():
        user = User.check_regiest_token(token)
        if user:
            user.password = reform.password.data
            db.session.commit()
            flash('密碼修改成功，請重新登入')
            return redirect(url_for('home.index'))
        else:
            return render_template('mail/fail_confirm.html')
    else: 
        return render_template('home/reset_password.html',reform=reform)
    



@home_bp.route("/forget_pa",methods=["POST","GET"])   #忘記密碼
def forget_pa():
    mess = forget_pa_sys()
    if mess == "":
        data = ['send_email']
        return render_template(session["notLogin"],data=data)
    data = [mess,'block']
    return render_template(session["notLogin"],data=data)


@home_bp.route('/',methods=["POST","GET"])              #主頁
@home_bp.route('/index',methods=["POST","GET"])
def index():
    return gather1('home/index.html','home_u.index2','','','')


@home_bp.route("/chat",methods=["POST","GET"])
@home_bp.route("/chat/<int:page>",methods=["POST","GET"])
def chat(page=1):
    return gather1('home/chat.html','home_u.chat2','哈拉板','home.chat',page)

@home_bp.route("/activity",methods=["POST","GET"])
@home_bp.route("/activity/<int:page>",methods=["POST","GET"])
def activity(page=1):
    return gather1('home/activity.html','home_u.activity2','活動分享區','home.activity',page)


@home_bp.route("/community",methods=["POST","GET"])
@home_bp.route("/community/<int:page>",methods=["POST","GET"])
def community(page=1):
    return gather1('home/community.html','home_u.community2','社群招生板','home.community',page)

@home_bp.route("/report",methods=["POST","GET"])
def report():
    return gather1('home/report.html','home_u.report2','','','')

@home_bp.route("/creat",methods=["POST","GET"])
@home_bp.route("/creat/<int:page>",methods=["POST","GET"])
def creat(page=1):
    return gather1('home/creat.html','home_u.creat2','藝術創作分享區','home.creat',page)

@home_bp.route("/java",methods=["POST","GET"])
@home_bp.route("/java/<int:page>",methods=["POST","GET"])
def java(page=1):
   return gather1('home/program/java.html','home_u.java2','Java程式','home.java',page)

@home_bp.route("/python",methods=["POST","GET"])
@home_bp.route("/python/<int:page>",methods=["POST","GET"])
def python(page=1):
    return gather1('home/program/python.html','home_u.python2','Python程式','home.python',page)

@home_bp.route("/Cp",methods=["POST","GET"])
@home_bp.route("/Cp/<int:page>",methods=["POST","GET"])
def Cp(page=1):
    return gather1('home/program/Cp.html','home_u.Cp2','C','home.Cp',page)

@home_bp.route("/cpp",methods=["POST","GET"])
@home_bp.route("/cpp/<int:page>",methods=["POST","GET"])
def cpp(page=1):
    return gather1('home/program/cpp.html','home_u.cpp2','C++程式','home.cpp',page)

@home_bp.route("/linux",methods=["POST","GET"])
@home_bp.route("/linux/<int:page>",methods=["POST","GET"])
def linux(page=1):
    return gather1('home/program/linux.html','home_u.linux2','Linux程式','home.linux',page)

@home_bp.route("/chemical",methods=["POST","GET"])
@home_bp.route("/chemical/<int:page>",methods=["POST","GET"])
def chemical(page=1):
    return gather1('home/money/chemical.html','home_u.chemical2','應用化學系','home.chemical',page)

@home_bp.route("/cosmetic",methods=["POST","GET"])
@home_bp.route("/cosmetic/<int:page>",methods=["POST","GET"])
def cosmetic(page=1):
    return gather1('home/money/cosmetic.html','home_u.cosmetic2','化妝品科學系','home.cosmetic',page)

@home_bp.route("/financial",methods=["POST","GET"])
@home_bp.route("/financial/<int:page>",methods=["POST","GET"])
def financial(page=1):
    return gather1('home/money/financial.html','home_u.financial2','財務工程學系','home.financial',page)

@home_bp.route("/food",methods=["POST","GET"])
@home_bp.route("/food/<int:page>",methods=["POST","GET"])
def food(page=1):
    return gather1('home/money/food.html','home_u.food2','食品營養學系','home.food',page)

@home_bp.route("/science",methods=["POST","GET"])
@home_bp.route("/science/<int:page>",methods=["POST","GET"])
def science(page=1):
    return gather1('home/money/science.html','home_u.science2','資訊科學學系','home.science',page)

@home_bp.route("/china",methods=["POST","GET"])
@home_bp.route("/china/<int:page>",methods=["POST","GET"])
def china(page=1):
    return gather1('home/people/china.html','home_u.china2','中國文學系','home.china',page)

@home_bp.route("/human",methods=["POST","GET"])
@home_bp.route("/human/<int:page>",methods=["POST","GET"])
def human(page=1):
    return gather1('home/people/human.html','home_u.human2','生態人文學系','home.human',page)

@home_bp.route("/law",methods=["POST","GET"])
@home_bp.route("/law/<int:page>",methods=["POST","GET"])
def law(page=1):
    return gather1('home/people/law.html','home_u.law2','法律學系','home.law',page)

@home_bp.route("/public",methods=["POST","GET"])
@home_bp.route("/public/<int:page>",methods=["POST","GET"])
def public(page=1):
    return gather1('home/people/public.html','home_u.public2','大眾傳播學系','home.public',page)

@home_bp.route("/taiwan",methods=["POST","GET"])
@home_bp.route("/taiwan/<int:page>",methods=["POST","GET"])
def taiwan(page=1):
    return gather1('home/people/taiwan.html','home_u.taiwan2','台灣文學系','home.taiwan',page)

@home_bp.route("/world",methods=["POST","GET"])
@home_bp.route("/world/<int:page>",methods=["POST","GET"])
def world(page=1):
    return gather1('home/people/world.html','home_u.world2','社會工作兒童少年福利學系','home.world',page)

@home_bp.route("/english",methods=["POST","GET"])
@home_bp.route("/english/<int:page>",methods=["POST","GET"])
def english(page=1):
    return gather1('home/language/english.html','home_u.english2','英國語文學系','home.english',page)

@home_bp.route("/japan",methods=["POST","GET"])
@home_bp.route("/japan/<int:page>",methods=["POST","GET"])
def japan(page=1):
    return gather1('home/language/japan.html','home_u.japan2','日本語文學系','home.japan',page)

@home_bp.route("/spain",methods=["POST","GET"])
@home_bp.route("/spain/<int:page>",methods=["POST","GET"])
def spain(page=1):
    return gather1('home/language/spain.html','home_u.spain2','西班牙語文學','home.spain',page)


