from flask import Blueprint

#  定義
home_bp = Blueprint('home', __name__)

#  關聯
from . import view