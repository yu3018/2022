<?php

namespace App\Docs;

/**
 * @OA\Tag(
 *   name="1. StockBasis",
 * ),
 * @OA\Tag(
 *   name="2. StockGetBulletin",
 * ),
 * @OA\Tag(
 *   name="3. StockGetcal",
 * ),
 *  * @OA\Tag(
 *   name="4. StockCal",
 * ),
 */

class Controller
{
}
