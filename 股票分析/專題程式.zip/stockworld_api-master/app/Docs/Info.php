<?php

namespace App\Docs;

/**
 * @OA\Info(
 *      version="1.0.0",
 *      title="stockworld",
 *      description=""
 * )
*/

class Info{

}