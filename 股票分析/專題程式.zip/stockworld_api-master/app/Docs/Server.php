<?php
namespace App\Docs;

/**
* @OA\server(
*      url = "https://stockworld.ddns.net/",
*      description="API主機"
* )
*/
class Server{

}