<?php

namespace App\Docs;

// /**
//  * @OA\SecurityScheme(
//  *      securityScheme="Authorization",
//  *      in="header",
//  *      type="http",
//  *      scheme="bearer",
//  *      name="Authorization"
//  * )
//  */
class Security
{
}
