<template>
    <div class="footer">
    </div>
</template>

<script>

export default {}
</script>
<style scoped>
@media only screen and (max-width: 768px) {
    .footer {
        height: 10vh;
    }
}
</style>